/// Zero‑allocation events emitted by the line assembler.
/// All variants borrow directly from the assembler’s ring buffer.
///
/// Future phases will add ANSI‑aware fragment types.
pub enum LineEvent<'a> {
    /// A complete line **without** the trailing newline.
    Line(&'a [u8]),
    /// Partial data left over after EOF flush.
    Partial(&'a [u8]),
    /// Forced flush because a line exceeded `max_line_len` without a newline.
    /// This is **not** a complete line – matching/highlighting should be suppressed.
    Overflow(&'a [u8]),
}