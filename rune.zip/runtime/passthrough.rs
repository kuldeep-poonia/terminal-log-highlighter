use crate::runtime::passthrough::Passthrough;
use crate::runtime::line_assembler::LineAssembler;
use crate::runtime::events::LineEvent;
use crate::matcher::{self, classifier::{Severity, PatternDef}};
use std::io::{self, Write};

pub struct Processor<W: Write> {
    passthrough: Passthrough<W>,
    assembler: LineAssembler,
    matcher: matcher::Matcher,
}

impl<W: Write> Processor<W> {
    pub fn with_defaults(passthrough: Passthrough<W>) -> Self {
        let defaults = vec![
            PatternDef { pattern: "error".into(), severity: Severity::Error },
            PatternDef { pattern: "warn".into(), severity: Severity::Warn },
            PatternDef { pattern: "timeout".into(), severity: Severity::Critical },
        ];
        let matcher = matcher::Matcher::from_patterns(&defaults);
        Self {
            passthrough,
            assembler: LineAssembler::new(),
            matcher,
        }
    }

    /// Process an incoming byte chunk.
    ///
    /// 1. Write raw bytes directly to the terminal (passthrough‑first).
    /// 2. Feed the same bytes into the line assembler and run the matcher
    ///    as a side‑channel. Matching does **not** delay output.
    pub fn process_chunk(&mut self, chunk: &[u8]) -> io::Result<()> {
        // Passthrough – never delayed by matching.
        self.passthrough.write_all(chunk)?;

        // Side‑channel: line assembly + matching.
        let matcher = &self.matcher;
        self.assembler.push(chunk, |event| {
            match event {
                LineEvent::Line(line) => {
                    // Match only on complete, logical lines.
                    let _result = matcher.check(line);
                    // Phase 4 will use _result for highlighting.
                }
                LineEvent::Overflow(_overflow) => {
                    // Overflow is not a logical line – suppress matching
                    // to avoid false amplification.
                }
                LineEvent::Partial(_) => {
                    // Only produced during final flush; handled there.
                }
            }
        });
        Ok(())
    }

    pub fn flush(&mut self) -> io::Result<()> {
        // Finalise any remaining partial data.
        self.assembler.flush(|event| {
            if let LineEvent::Partial(data) = event {
                // Matching on EOF partial is optional; we skip it here.
                let _ = self.matcher.check(data);
            }
        });
        self.passthrough.flush()
    }
}