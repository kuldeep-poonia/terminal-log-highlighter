use crate::runtime::passthrough::Passthrough;
use crate::runtime::line_assembler::LineAssembler;
use crate::runtime::events::LineEvent;
use crate::matcher::{self, classifier::{Severity, PatternDef}};
use std::io::{self, Write};

pub struct Processor<W: Write> {
    passthrough: Passthrough<W>,
    assembler: LineAssembler,
    matcher: matcher::Matcher,
    // Future: store matched lines / offsets for highlighting
}

impl<W: Write> Processor<W> {
    /// Create a processor with a default danger‑pattern set.
    pub fn with_defaults(passthrough: Passthrough<W>) -> Self {
        let defaults = vec![
            PatternDef { pattern: "error".into(), severity: Severity::Error },
            PatternDef { pattern: "warn".into(), severity: Severity::Warn },
            PatternDef { pattern: "timeout".into(), severity: Severity::Critical },
        ];
        let matcher = matcher::Matcher::from_patterns(&defaults);
        Self {
            passthrough,
            assembler: LineAssembler::new(),
            matcher,
        }
    }

    /// Process an incoming byte chunk.
    ///
    /// 1. Write raw bytes directly to the terminal (preserves exact stream).
    /// 2. Feed the same bytes to the line assembler for side‑channel matching.
    pub fn process_chunk(&mut self, chunk: &[u8]) -> io::Result<()> {
        // Passthrough first – never delayed by matching.
        self.passthrough.write_all(chunk)?;

        // Side channel: line assembly and matching.
        let matcher = &self.matcher;
        self.assembler.push(chunk, |event| {
            match event {
                LineEvent::Line(line) | LineEvent::Overflow(line) => {
                    // Matching runs after passthrough – does not block output.
                    let _result = matcher.check(line);
                    // Phase 4 will use _result for highlighting.
                }
                LineEvent::Partial(_) => {
                    // Partial events are only produced during flush; ignored here.
                }
            }
        });
        Ok(())
    }

    pub fn flush(&mut self) -> io::Result<()> {
        // Finalise any remaining partial data from the assembler.
        self.assembler.flush(|event| {
            if let LineEvent::Partial(data) = event {
                // Matching on EOF partial is possible but not required.
                let _ = self.matcher.check(data);
            }
        });
        // Ensure all output is flushed at end of stream.
        self.passthrough.flush()
    }
}