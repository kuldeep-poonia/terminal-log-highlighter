use crate::runtime::chunk_reader::ChunkReader;
use crate::runtime::processor::Processor;
use std::io::{self, BufRead, Write};

pub fn process_stream<R: BufRead, W: Write>(
    mut reader: ChunkReader<R>,
    mut processor: Processor<W>,
) -> io::Result<()> {
    loop {
        match reader.read_chunk()? {
            Some(chunk) => processor.process_chunk(chunk)?,
            None => break,
        }
    }
    processor.flush()
}