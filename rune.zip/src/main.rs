mod runtime;
mod matcher;

fn main() {
    // Invisible runtime: no output on failure, but non‑zero exit code.
    // In a later phase, SENTINEL_DEBUG can enable silent diagnostics.
    if let Err(e) = runtime::run() {
        std::process::exit(e.raw_os_error().unwrap_or(1));
    }
}