use aho_corasick::AhoCorasick;
use super::classifier::{MatchResult, Severity};

pub struct AhoMatcher {
    ac: AhoCorasick,
    patterns: Vec<String>,
    severities: Vec<Severity>,
}

impl AhoMatcher {
    pub fn new(literals: &[String], severities: &[Severity]) -> Self {
        let ac = AhoCorasick::new(literals).expect("aho-corasick build failure");
        Self {
            ac,
            patterns: literals.to_vec(),
            severities: severities.to_vec(),
        }
    }

    pub fn check<'a>(&'a self, line: &'a [u8]) -> Option<MatchResult<'a>> {
        self.ac.find(line).map(|mat| {
            let idx = mat.pattern();
            MatchResult {
                pattern: self.patterns[idx].as_str(),
                severity: self.severities[idx],
                offset: mat.start(),
            }
        })
    }
}