#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Severity {
    Info,
    Warn,
    Error,
    Critical,
}

#[derive(Debug, Clone)]
pub struct PatternDef {
    pub pattern: String,
    pub severity: Severity,
}

#[derive(Debug)]
pub struct MatchResult<'a> {
    pub pattern: &'a str,
    pub severity: Severity,
    pub offset: usize,
}