use super::classifier::{MatchResult, Severity};
use memchr::memmem;

pub struct SimpleMatcher {
    pattern: String,
    severity: Severity,
}

impl SimpleMatcher {
    pub fn new(pattern: &str, severity: Severity) -> Self {
        Self {
            pattern: pattern.to_owned(),
            severity,
        }
    }

    pub fn check<'a>(&'a self, line: &'a [u8]) -> Option<MatchResult<'a>> {
        memmem::find(line, self.pattern.as_bytes()).map(|offset| MatchResult {
            pattern: self.pattern.as_str(),
            severity: self.severity,
            offset,
        })
    }
}