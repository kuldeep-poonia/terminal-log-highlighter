pub mod simple;
pub mod aho;
#[cfg(feature = "regex")]
pub mod regex;
pub mod classifier;
pub mod threshold;

use classifier::{MatchResult, PatternDef, Severity};
use simple::SimpleMatcher;
use aho::AhoMatcher;

pub enum Matcher {
    Noop,
    Simple(SimpleMatcher),
    SingleByte {
        byte: u8,
        pattern: String,
        severity: Severity,
    },
    Aho(AhoMatcher),
    #[cfg(feature = "regex")]
    Regex(regex::bytes::Regex, String, Severity),
}

impl Matcher {
    pub fn from_pattern(def: &PatternDef) -> Self {
        if def.pattern.is_empty() {
            return Matcher::Noop;
        }
        if def.pattern.as_bytes().len() == 1 {
            Matcher::SingleByte {
                byte: def.pattern.as_bytes()[0],
                pattern: def.pattern.clone(),
                severity: def.severity,
            }
        } else {
            Matcher::Simple(SimpleMatcher::new(&def.pattern, def.severity))
        }
    }

    pub fn from_patterns(defs: &[PatternDef]) -> Self {
        if defs.is_empty() {
            return Matcher::Noop;
        }
        if defs.len() == 1 {
            return Self::from_pattern(&defs[0]);
        }
        let literals: Vec<String> = defs.iter().map(|d| d.pattern.clone()).collect();
        let severities: Vec<Severity> = defs.iter().map(|d| d.severity).collect();
        Matcher::Aho(AhoMatcher::new(&literals, &severities))
    }

    /// Checks a line for a danger match.
    /// The returned `MatchResult` borrows strings from the matcher.
    pub fn check<'a>(&'a self, line: &'a [u8]) -> Option<MatchResult<'a>> {
        match self {
            Matcher::Noop => None,
            Matcher::Simple(s) => s.check(line),
            Matcher::SingleByte { byte, pattern, severity } => {
                memchr::memchr(*byte, line).map(|offset| MatchResult {
                    pattern: pattern.as_str(),
                    severity: *severity,
                    offset,
                })
            }
            Matcher::Aho(a) => a.check(line),
            #[cfg(feature = "regex")]
            Matcher::Regex(re, pattern, severity) => {
                re.find(line).map(|m| MatchResult {
                    pattern: pattern.as_str(),
                    severity: *severity,
                    offset: m.start(),
                })
            }
        }
    }
}